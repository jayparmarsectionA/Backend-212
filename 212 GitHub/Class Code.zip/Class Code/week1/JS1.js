// const lodash = require("lodash")
import lodash_2 from "lodash";

export const greeting = () => {
    console.log("Hello There")
};
greeting();