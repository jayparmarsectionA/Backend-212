import {greeting} from "./JS1.js"
greeting()